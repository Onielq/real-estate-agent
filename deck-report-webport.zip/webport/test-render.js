const fs = require("fs");
const path = require("path");
const ICONS = require("./icons.js");
const { lineTrend, barH } = require("./charts.js");
const { renderDeck } = require("./render.js");

global.ICONS = ICONS;
global.lineTrend = lineTrend;
global.barH = barH;

const data = JSON.parse(fs.readFileSync(path.join(__dirname, "example_data.json"), "utf8"));

// point image paths at the same placeholder used by the python system, so
// this test run visually matches what we already validated
data.agent.photo = "../deck-system/data/placeholder_avatar.png";

const bodyHtml = renderDeck(data);

const css = fs.readFileSync(path.join(__dirname, "deck-report.css"), "utf8");

const fullHtml = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><style>${css}</style></head>
<body><div id="deck-report">${bodyHtml}</div></body></html>`;

fs.writeFileSync(path.join(__dirname, "test-output.html"), fullHtml);
console.log("Wrote test-output.html —", bodyHtml.length, "chars of page HTML");
console.log("Page divs found:", (bodyHtml.match(/class="page/g) || []).length);

// --- weasyprint-only sanity-check addendum: force pagination the same way
// the browser's @media print block does, since this harness renders
// directly (not via a browser print dialog). Not part of the real module.
const paginationTestCss = `
@page { size: 13.333in 7.5in; margin: 0; }
#deck-report .page { margin: 0; box-shadow: none; break-after: page; }
#deck-report .page:last-child { break-after: avoid; }
`;
const testHtml = fullHtml.replace("</style>", paginationTestCss + "</style>");
fs.writeFileSync(path.join(__dirname, "test-output-paginated.html"), testHtml);
console.log("Wrote test-output-paginated.html for weasyprint sanity check");
