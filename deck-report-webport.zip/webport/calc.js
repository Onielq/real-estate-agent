// ============================================================
// CALC / VALIDATE — the analytical layer between raw project data
// and the renderer. Nothing here is presentation logic; it only
// computes numbers and flags data problems. Pure functions, no DOM.
//
// Design principle (per the spec this was built against): keep a
// hard line between
//   SOURCE data      — what the project data literally states
//   CALCULATED data  — arithmetic on source data (psf, % diff)
//   ANALYSIS         — a conclusion drawn from calculated data
//   ASSUMPTION       — anything modeled/estimated, always labeled
// The renderer is responsible for labeling calculated/analysis
// content as such when it displays it — this file just produces
// the numbers and never invents one it can't derive from the data.
// ============================================================

function toNumber(v) {
  if (typeof v === "number") return v;
  if (!v) return null;
  const s = String(v).trim();
  // Handle "AED 2.14M" / "2.14M" / "AED 1.97 Million" style magnitude
  // suffixes explicitly — a naive digit-strip would silently turn
  // "2.14M" into 2.14 and be wrong by six orders of magnitude.
  const m = s.match(/([\d,.]+)\s*(million|m\b|k\b|thousand)?/i);
  if (!m) return null;
  let n = parseFloat(m[1].replace(/,/g, ""));
  if (!Number.isFinite(n)) return null;
  const suffix = (m[2] || "").toLowerCase();
  if (suffix.startsWith("m")) n *= 1_000_000;
  else if (suffix.startsWith("k") || suffix.startsWith("t")) n *= 1_000;
  return n;
}

/**
 * Per-unit-type metrics derived from the unit table. Prefers explicit
 * numeric fields (avgPriceNum, sizeAvgNum, startingNum) when the data
 * provides them — those are unambiguous. Falls back to parsing the
 * display strings (starting/average/size) only when numeric fields
 * are absent, via the magnitude-aware parser above.
 */
function computeUnitMetrics(unitTable) {
  return (unitTable || []).map((u) => {
    const price = toNumber(u.avgPriceNum) ?? toNumber(u.average) ?? toNumber(u.startingNum) ?? toNumber(u.starting);
    const size = toNumber(u.sizeAvgNum) ?? toNumber(u.sizeMinNum) ?? toNumber(u.size);
    const psf = price && size ? price / size : null;
    return {
      type: u.type,
      units: u.units,
      price,
      size,
      psf,
      psfDisplay: psf ? `AED ${Math.round(psf).toLocaleString()}` : "Data unavailable",
    };
  });
}

/**
 * Best-value scoring across unit types. Lower AED/sq ft and larger
 * average size both score positively; entry price is scored inverse
 * (more accessible = higher score) but weighted lightly, since it's
 * a secondary consideration relative to actual value-for-money.
 * Weights are a plain constant, not hidden magic numbers — change
 * them here if the investment thesis for a project calls for it.
 */
const DEFAULT_SCORE_WEIGHTS = { psf: 0.55, size: 0.25, entryPrice: 0.20 };

function computeBestUnit(unitTable, weights = DEFAULT_SCORE_WEIGHTS) {
  const metrics = computeUnitMetrics(unitTable);
  const scoreable = metrics.filter((m) => m.psf && m.size && m.price);
  if (scoreable.length < 2) {
    return { metrics, winner: null, reason: "Not enough priced unit types to compare." };
  }

  const psfVals = scoreable.map((m) => m.psf);
  const sizeVals = scoreable.map((m) => m.size);
  const priceVals = scoreable.map((m) => m.price);
  const norm = (v, arr, invert) => {
    const min = Math.min(...arr), max = Math.max(...arr);
    if (max === min) return 0.5;
    const n = (v - min) / (max - min);
    return invert ? 1 - n : n;
  };

  let winner = null, bestScore = -Infinity;
  for (const m of scoreable) {
    const score =
      norm(m.psf, psfVals, true) * weights.psf +
      norm(m.size, sizeVals, false) * weights.size +
      norm(m.price, priceVals, true) * weights.entryPrice;
    m.score = score;
    if (score > bestScore) { bestScore = score; winner = m; }
  }

  return { metrics, winner, weights };
}

/**
 * District/market premium-discount, computed only when both sides
 * of the comparison exist in source data. Returns null (not a
 * fabricated %) if district average psf is missing.
 */
function computeDistrictComparison(projectPsf, districtAvgPsf) {
  const p = toNumber(projectPsf);
  const d = toNumber(districtAvgPsf);
  if (!p || !d) return null;
  const diffPct = ((d - p) / d) * 100;
  return {
    projectPsf: p,
    districtAvgPsf: d,
    diffPct: Math.round(diffPct * 10) / 10,
    direction: diffPct > 0 ? "below" : "above",
    display: `${Math.abs(Math.round(diffPct * 10) / 10)}% ${diffPct > 0 ? "below" : "above"} district average`,
  };
}

/**
 * Payment plan validation. Arbitrary number of instalments, any
 * split (20/80, 60/40, 9-tranche construction-linked, whatever).
 * Auto-identifies the final instalment rather than requiring a
 * hand-set flag, and flags the plan if it doesn't sum to 100%.
 */
function validatePaymentPlan(plan) {
  if (!Array.isArray(plan) || plan.length === 0) {
    return { valid: false, total: 0, warning: "No payment plan data provided." };
  }
  const total = plan.reduce((sum, p) => sum + (toNumber(p.pct) ?? 0), 0);
  const rounded = Math.round(total * 10) / 10;
  const valid = Math.abs(rounded - 100) < 0.1;
  return {
    valid,
    total: rounded,
    warning: valid ? null : `Payment plan instalments sum to ${rounded}%, not 100% — check the source data before sending this report out.`,
  };
}

/**
 * Full project-data validation. Returns a list of human-readable
 * warnings; an empty list means the report is safe to render and
 * export as-is. Never throws — a malformed project should degrade
 * to "here's what's wrong," not a broken page.
 */
function validateProjectData(data) {
  const warnings = [];
  const req = (val, label) => { if (!val) warnings.push(`Missing ${label}.`); };

  req(data?.project?.name, "project name");
  req(data?.project?.location, "location");
  req(data?.agent?.name, "presenter name");

  const units = data?.page2?.unit_table;
  if (!units || units.length === 0) {
    warnings.push("No unit types defined — pages 2 and 4 will show as empty.");
  } else {
    units.forEach((u, i) => {
      if (!u.type) warnings.push(`Unit row ${i + 1} is missing a type label.`);
      if (!u.starting && !u.average) warnings.push(`"${u.type || "Unit row " + (i + 1)}" has no price data.`);
    });
  }

  const pp = validatePaymentPlan(data?.page2?.payment_plan);
  if (pp.warning) warnings.push(pp.warning);

  return { warnings, paymentPlan: pp };
}

if (typeof module !== "undefined") {
  module.exports = {
    toNumber,
    computeUnitMetrics,
    computeBestUnit,
    computeDistrictComparison,
    validatePaymentPlan,
    validateProjectData,
    DEFAULT_SCORE_WEIGHTS,
  };
}
