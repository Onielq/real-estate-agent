// Renders the 5-page property launch deck as an HTML string, given a data
// object with the same shape as the Python system's JSON schema.
// Ported 1:1 from deck-system/template/deck.html.j2 — keep class names in
// sync with style.css (also ported, see deck-report.css).

if (typeof module !== "undefined") {
  // Node test harness only — in the browser these come from the
  // preceding <script> tags as globals (ICONS, lineTrend, barH, and
  // now the calc.js exports), same pattern as icons/charts already use.
  var { computeUnitMetrics, computeBestUnit, computeDistrictComparison, validatePaymentPlan, validateProjectData } = require("./calc.js");
}

function esc(s) {
  return (s ?? "").toString();
}

function renderDeck(data) {
  const { agent, project, page2, page3, page4, page5 } = data;
  const footerLeft = data.footer_left;
  const footerBrand = data.footer_brand;
  const watermark = data.watermark;

  const ph = (label, extraStyle = "") =>
    `<div class="ph" style="width:100%;height:100%;${extraStyle}">[ Insert: ${label} ]</div>`;

  // ---------- PAGE 1 : COVER ----------
  const statRows = project.stats
    .map(
      (s) => `
      <div class="stat-row">
        <div class="icon-badge">${ICONS[s.icon]?.({ color: "#d8be86", size: 20 }) ?? ""}</div>
        <div>
          <div class="stat-value">${esc(s.value)}</div>
          <div class="stat-label">${esc(s.label)}</div>
        </div>
      </div>`
    )
    .join("");

  const page1 = `
<div class="page cover">
  <div class="sidebar">
    <div class="presented-by">
      <div class="avatar"><img src="${esc(agent.photo)}"></div>
      <div class="meta">
        <div class="label">Presented by</div>
        <div class="name">${esc(agent.name)}</div>
        <div class="handle">${esc(agent.handle)}</div>
      </div>
    </div>
    <hr class="rule">
    <div class="tag">${esc(project.tag)}</div>
    <div class="project-name">${esc(project.name)}</div>
    <div class="locality">${esc(project.location).toUpperCase()}</div>
    <div class="plot">${esc(project.district)}</div>
    <hr class="rule">
    <div class="stats">${statRows}</div>
    <div class="price-box">
      <div class="label">STARTING FROM</div>
      <div class="value">${esc(project.starting_price)}</div>
    </div>
  </div>
  <div class="hero">
    ${project.hero_image ? `<img src="${esc(project.hero_image)}">` : ph("hero render: exterior tower photo/CGI, landscape")}
    ${watermark ? `<div class="watermark">${esc(watermark)} &nbsp; ${esc(watermark)} &nbsp; ${esc(watermark)}</div>` : ""}
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">01 / LAUNCH OVERVIEW</div>
  </div>
</div>`;

  // ---------- PAGE 2 : INVESTMENT CASE ----------
  const unitRows = page2.unit_table
    .map(
      (r) => `
          <tr class="${r.starred ? "hi" : ""}">
            <td>${esc(r.type)}${r.starred ? ' <span class="star">&#9733;</span>' : ""}</td>
            <td class="num">${esc(r.units)}</td>
            <td class="num">${esc(r.size)}</td>
            <td class="num">${esc(r.starting)}</td>
            <td class="num">${esc(r.average)}</td>
            <td class="num">${esc(r.max)}</td>
          </tr>`
    )
    .join("");

  const ppChips = page2.payment_plan
    .map((p, i) => {
      const pctDisplay = typeof p.pct === "number" ? `${p.pct}%` : esc(p.pct);
      const isFinal = p.final || i === page2.payment_plan.length - 1;
      return `
        <div class="pp-chip ${isFinal ? "final" : ""}">
          <div class="pct">${pctDisplay}</div>
          <div class="when">${esc(p.when)}</div>
        </div>`;
    })
    .join("");

  const page2Html = `
<div class="page p2">
  <div class="headline">${esc(page2.headline)}</div>
  <div class="subhead">${esc(page2.subhead)}</div>
  <div class="body">
    <div class="col-left">
      <table class="unit-table">
        <colgroup>
          <col style="width:27%"><col style="width:11%"><col style="width:17%">
          <col style="width:15%"><col style="width:15%"><col style="width:15%">
        </colgroup>
        <thead>
          <tr>
            <th>Type</th><th class="num">Units</th><th class="num">Size (sq ft)</th>
            <th class="num">Starting</th><th class="num">Average</th><th class="num">Max</th>
          </tr>
        </thead>
        <tbody>${unitRows}</tbody>
      </table>
      <div class="table-foot">${esc(page2.table_foot)}</div>

      <div class="pp-title">PAYMENT PLAN</div>
      <div class="pp-row">${ppChips}</div>
      <div class="pp-note">${esc(page2.payment_note)}</div>

      <div class="metrics-row">
        <div class="metric-box">
          <div class="val">${esc(page2.market_metric?.value) || "TBC"}</div>
          <div class="lbl">${esc(page2.market_metric?.label) || "Data unavailable — market sales figures not yet compiled."}</div>
        </div>
        <div class="metric-box trend-box">
          <div class="trend-title">${esc(page2.price_trend?.title)}</div>
          ${page2.price_trend?.points?.length >= 2 ? lineTrend(page2.price_trend.points, { width: 300, height: 78 }) : `<div style="font-size:7.6pt; color:var(--ink-faint); font-style:italic; padding-top:0.2in;">Data unavailable — not enough price history to chart a trend.</div>`}
        </div>
      </div>
    </div>
    <div class="col-right">
      ${
        page2.differentiator
          ? `<div class="side-panel">
        <div class="eyebrow on-dark">${esc(page2.differentiator.eyebrow)}</div>
        <div class="title">${esc(page2.differentiator.title)}</div>
        <div class="fig">
          ${page2.differentiator.image ? `<img src="${esc(page2.differentiator.image)}">` : `<div class="ph" style="height:2.1in;">[ Insert: floor plan / layout diagram ]</div>`}
        </div>
        <div class="cap">${esc(page2.differentiator.caption)}</div>
        <div class="hl">${page2.differentiator.highlight ?? ""}</div>
        <div class="note">${page2.differentiator.note ?? ""}</div>
      </div>`
          : `<div class="side-panel"><div class="eyebrow on-dark">DIFFERENTIATOR</div><div class="note" style="margin-top:0.14in; border-top:none; padding-top:0;">Data unavailable — no differentiator angle has been written up for ${esc(project.name)} yet.</div></div>`
      }
    </div>
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">02 / THE INVESTMENT CASE</div>
  </div>
</div>`;

  // ---------- PAGE 3 : MASTERPLAN / DISTRICTS ----------
  const jewelItems = (page3.jewels?.names || [])
    .map((name) => `<div class="jewel-item">${ICONS.pin({ color: "#b5893a", size: 15, sw: 1.7 })} ${esc(name)}</div>`)
    .join("");

  const districtCards = (page3.district_cards || [])
    .map((c) => `<div class="district-card"><h4>${esc(c.name)}</h4><p>${esc(c.body)}</p></div>`)
    .join("");

  const aroundItems = (page3.getting_around?.list || [])
    .map(
      (a) => `
      <div class="around-item">
        <div class="badge">${ICONS[a.icon]?.({ color: "#13213b", size: 18, sw: 1.6 }) ?? ""}</div>
        <div><div class="num">${esc(a.value)}</div><div class="lbl">${esc(a.label)}</div></div>
      </div>`
    )
    .join("");

  const page3Html = `
<div class="page p3">
  <div class="p3-hero">
    ${page3.hero_image ? `<img src="${esc(page3.hero_image)}">` : ""}
    <div class="scrim"></div>
    <div class="inner">
      <div class="eyebrow">${esc(page3.hero_subhead)}</div>
      <h1>${esc(page3.hero_headline) || `${esc(project.name)} — district information pending`}</h1>
    </div>
    <div class="brandmark">
      <div class="dot">${esc(footerBrand).charAt(0).toUpperCase()}</div>
      ${esc(footerBrand)}
    </div>
  </div>
  <div class="p3-body">
    <div class="cols">
      <div class="col-map">
        <div class="map-img">
          ${page3.map_image ? `<img src="${esc(page3.map_image)}">` : ph("masterplan / district map")}
        </div>
        <div class="districts-title">${esc(page3.districts_title)}</div>
        <div class="districts-body">${esc(page3.districts_body)}</div>
        <div class="live-today">${page3.live_today ?? ""}</div>
        <div class="note-gold">${esc(page3.note)}</div>
      </div>
      <div class="col-jewels">
        <div class="eyebrow">${esc(page3.jewels?.eyebrow) || "THE CITY JEWELS"}</div>
        <div class="jewels-intro">${esc(page3.jewels?.intro)}</div>
        ${jewelItems ? `<div class="jewels-grid">${jewelItems}</div>` : `<div style="font-size:8.6pt; color:var(--ink-faint); font-style:italic; margin-top:0.14in;">Data unavailable — district amenity list not yet compiled.</div>`}
      </div>
    </div>
    <div class="district-cards">${districtCards || `<div style="font-size:8pt; color:var(--ink-faint); font-style:italic; padding:0.1in 0;">Data unavailable — sub-district profiles not yet compiled for ${esc(project.name)}.</div>`}</div>
    <div class="around-title">GETTING AROUND THE CLUSTER</div>
    <div class="around-row">${aroundItems || `<div style="font-size:8pt; color:var(--ink-faint); font-style:italic;">Data unavailable — infrastructure stats not yet compiled.</div>`}</div>
    <div class="around-caption">${esc(page3.getting_around?.caption)}</div>
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">03 / THE DISTRICTS</div>
  </div>
</div>`;

  // ---------- PAGE 4 : COMPARABLES ----------
  const unitMetrics = computeUnitMetrics(page2.unit_table);
  const bestUnit = computeBestUnit(page2.unit_table);

  const compRows = (page4.comparison_table || [])
    .map((r) => `<tr><td>${esc(r.segment)}</td><td class="num">${esc(r.value)}</td><td>${esc(r.vs)}</td></tr>`)
    .join("");

  const oppStats = (page4.opportunity?.stats || [])
    .map((s) => `<div class="opp-stat"><div class="num">${esc(s.value)}</div><div class="body">${esc(s.body)}</div></div>`)
    .join("");

  // Bars: use explicit page4.bars if the project data supplies them,
  // otherwise compute AED/sq ft per unit type directly from the unit
  // table so this works for any project without hand-authored bars.
  const bars =
    page4.bars && page4.bars.length
      ? page4.bars
      : unitMetrics
          .filter((m) => m.psf)
          .map((m) => ({ label: m.type, value: Math.round(m.psf), display: Math.round(m.psf).toLocaleString() }));

  // Best-value callout: a CALCULATED conclusion, kept visually and
  // textually distinct from the curated "opportunity" commentary
  // (which is sourced/researched narrative, not a formula's output).
  const bestValueBlock = bestUnit.winner
    ? `
      <div class="calc-block">
        <div class="calc-label">CALCULATED &middot; BEST RELATIVE VALUE</div>
        <div class="calc-headline">${esc(bestUnit.winner.type)}</div>
        <div class="calc-sub">${bestUnit.winner.psfDisplay}/sq ft avg &middot; ${bestUnit.winner.size ? Math.round(bestUnit.winner.size).toLocaleString() + " sq ft avg" : ""}</div>
        <div class="calc-note">Scored on price/sq ft, average size, and entry price across this project's own unit types (weights: psf ${Math.round(bestUnit.weights.psf * 100)}%, size ${Math.round(bestUnit.weights.size * 100)}%, entry price ${Math.round(bestUnit.weights.entryPrice * 100)}%). This is a relative comparison within ${esc(project.name)} only — not a comparison against other projects, and not a promise of resale performance.</div>
      </div>`
    : "";

  const page4Html = `
<div class="page p4">
  <div class="headline">${esc(page4.headline)}</div>
  <div class="subhead">${esc(page4.subhead)}</div>
  <div class="body">
    <div class="col-left">
      ${
        page4.comparison_table
          ? `<table class="comp-table">
        <colgroup><col style="width:46%"><col style="width:24%"><col style="width:30%"></colgroup>
        <thead><tr><th>Segment</th><th>AED / sq ft</th><th>vs ${esc(project.name)}</th></tr></thead>
        <tbody>
          ${compRows}
          ${
            page4.highlight_row
              ? `<tr class="hi">
            <td>${esc(page4.highlight_row.segment)}</td>
            <td class="num val">${esc(page4.highlight_row.value)}</td>
            <td>${esc(page4.highlight_row.vs)}</td>
          </tr>`
              : ""
          }
        </tbody>
      </table>
      <div class="table-note">${esc(page4.table_note)}</div>`
          : `<div class="ph" style="height:1.4in;">[ Data unavailable: no district/market comparison data supplied for this project yet ]</div>`
      }
      <div class="bar-title">${esc(page4.bar_title) || `${esc(project.name).toUpperCase()} — AED / SQ FT BY UNIT TYPE`}</div>
      <div class="bar-chart">${bars.length ? barH(bars, { width: 566, rowH: 34 }) : ""}</div>
      ${bestValueBlock}
    </div>
    <div class="col-right">
      ${
        page4.opportunity
          ? `<div class="opp-panel">
        <div class="eyebrow">${esc(page4.opportunity.eyebrow)}</div>
        ${oppStats}
        <hr class="opp-rule">
        <div class="opp-note">${page4.opportunity.note ?? ""}</div>
      </div>`
          : `<div class="opp-panel"><div class="eyebrow">THE OPPORTUNITY</div><div class="opp-note" style="margin-top:0.14in;">Data unavailable — no researched market-opportunity commentary has been compiled for ${esc(project.name)} yet.</div></div>`
      }
    </div>
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">04 / COMPARABLES</div>
  </div>
</div>`;

  // ---------- PAGE 5 : LOCATION & LIFESTYLE ----------
  const mallStats = (page5.mall_stats || [])
    .map((s) => `<div class="stat"><div class="val">${esc(s.value)}</div><div class="lbl">${esc(s.label)}</div></div>`)
    .join("");

  const nearbyItems = (page5.nearby_stats || [])
    .map(
      (n) => `
      <div class="nearby-item">
        <div class="badge">${ICONS[n.icon]?.({ color: "#13213b", size: 16, sw: 1.6 }) ?? ""}</div>
        <div class="txt"><b>${esc(n.value)}</b> ${esc(n.label)}</div>
      </div>`
    )
    .join("");

  const page5Html = `
<div class="page p5">
  <div class="headline">${esc(page5.headline)}</div>
  <div class="subhead">${esc(page5.subhead)}</div>
  <div class="hero-imgs">
    <div class="mall-col">
      <div class="mall-img">
        ${page5.mall_image ? `<img src="${esc(page5.mall_image)}">` : ph("landmark / amenity photo")}
        <div class="cap">${esc(page5.mall_caption)}</div>
      </div>
      <div class="mall-stats">${mallStats}</div>
    </div>
    <div class="map-col">
      <div class="map-img">
        ${page5.location_map_image ? `<img src="${esc(page5.location_map_image)}">` : ph("location map")}
      </div>
      <div class="map-caption">${esc(page5.location_caption)}</div>
    </div>
  </div>
  <div class="bottom-band">
    <div class="nearby-panel">${nearbyItems}</div>
    <div class="contact-card">
      <div class="avatar"><img src="${esc(agent.photo)}"></div>
      <div class="name">${esc(agent.name)}</div>
      <div class="sub">${esc(footerBrand)} &middot; ${esc(agent.handle)}</div>
    </div>
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">05 / LOCATION &amp; LIFESTYLE</div>
  </div>
</div>`;

  // ---------- PAGE 6 : INVESTMENT RETURNS (optional — only when the
  // project has real yield/appreciation modeling behind it; unlike the
  // other pages, a placeholder "data unavailable" version of a returns
  // page isn't useful, so this page is simply omitted when absent) ----------
  let page6Html = "";
  if (data.page6) {
    const page6 = data.page6;
    const yieldRows = (page6.yield_table || [])
      .map((r) => `<tr class="${r.highlight ? "hi" : ""}"><td>${esc(r.segment)}</td><td class="num">${esc(r.yield)}</td></tr>`)
      .join("");
    const scenarioCards = (page6.appreciation_scenarios || [])
      .map(
        (s) => `
        <div class="scenario-card ${s.highlight ? "hi" : ""}">
          <div class="lbl">${esc(s.label)}</div>
          <div class="cagr">${esc(s.cagr)}</div>
          <div class="val">${esc(s.value)}</div>
          <div class="gain">${esc(s.gain)}</div>
        </div>`
      )
      .join("");
    const exitRows = (page6.exit_case?.rows || [])
      .map((r) => `<div class="exit-row ${r.highlight ? "hi" : ""}"><div class="k">${esc(r.label)}</div><div class="v">${esc(r.value)}</div></div>`)
      .join("");

    page6Html = `
<div class="page p6">
  <div class="headline">${esc(page6.headline)}</div>
  <div class="subhead">${esc(page6.subhead)}</div>
  <div class="body">
    <div class="col-left">
      <table class="yield-table">
        <colgroup><col style="width:60%"><col style="width:40%"></colgroup>
        <thead><tr><th>Segment</th><th class="num">Gross rental yield</th></tr></thead>
        <tbody>${yieldRows}</tbody>
      </table>
      <div class="yield-note">${esc(page6.yield_note)}</div>

      <div class="scenario-title">${esc(page6.appreciation_title)}</div>
      <div class="scenario-cards">${scenarioCards}</div>
      <div class="appreciation-note">${esc(page6.appreciation_note)}</div>
    </div>
    <div class="col-right">
      <div class="exit-panel">
        <div class="eyebrow on-dark">${esc(page6.exit_case?.eyebrow)}</div>
        <div class="title">${esc(page6.exit_case?.title)}</div>
        ${exitRows}
        <div class="exit-note">${page6.exit_case?.note ?? ""}</div>
      </div>
    </div>
  </div>
  <div class="footer">
    <div>${esc(footerLeft)}</div>
    <div class="brand">${esc(footerBrand)}</div>
    <div class="pageno">06 / INVESTMENT RETURNS</div>
  </div>
</div>`;
  }

  return page1 + page2Html + page3Html + page4Html + page5Html + page6Html;
}

if (typeof module !== "undefined") module.exports = { renderDeck, validateProjectData };
