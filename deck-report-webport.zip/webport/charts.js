// SVG chart generators — ported 1:1 from template/charts.py.

function lineTrend(points, { width = 300, height = 90, color = "#c9a15a", axisColor = "#8993a0" } = {}) {
  const n = points.length;
  if (n < 2) return "";
  const padL = 26, padR = 26, padT = 22, padB = 18;
  const plotW = width - padL - padR;
  const plotH = height - padT - padB;
  const vals = points.map((p) => p.value);
  const vmin = Math.min(...vals);
  const vmax = Math.max(...vals);
  const vspan = (vmax - vmin) || 1;
  const xs = points.map((_, i) => padL + (i / (n - 1)) * plotW);
  const ys = vals.map((v) => padT + plotH - ((v - vmin) / vspan) * plotH);

  const path = xs.map((x, i) => `${i === 0 ? "M" : "L"} ${x.toFixed(1)} ${ys[i].toFixed(1)}`).join(" ");
  const dots = xs.map((x, i) => `<circle cx="${x.toFixed(1)}" cy="${ys[i].toFixed(1)}" r="2.6" fill="${color}"/>`).join("");
  const anchors = n > 2 ? ["start", ...Array(n - 2).fill("middle"), "end"] : ["start", "end"];
  const labelsV = xs
    .map((x, i) => `<text x="${x.toFixed(1)}" y="${(ys[i] - 8).toFixed(1)}" font-size="9" font-weight="700" fill="#16232f" text-anchor="${anchors[i]}" font-family="Inter">${vals[i].toLocaleString()}</text>`)
    .join("");
  const labelsX = xs
    .map((x, i) => `<text x="${x.toFixed(1)}" y="${height - 4}" font-size="7.6" fill="${axisColor}" text-anchor="${anchors[i]}" font-family="Inter">${points[i].label}</text>`)
    .join("");

  return `<svg viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"><path d="${path}" fill="none" stroke="${color}" stroke-width="2"/>${dots}${labelsV}${labelsX}</svg>`;
}

function barH(items, { width = 380, rowH = 26, color = "#13213b", track = "#ede9de", highlightColor = "#c9a15a" } = {}) {
  const n = items.length;
  const height = n * rowH;
  const vmax = Math.max(...items.map((i) => i.value)) || 1;
  const labelW = 78, valW = 46;
  const barMax = width - labelW - valW - 8;

  const rows = items
    .map((item, i) => {
      const y = i * rowH;
      const bw = Math.max(4, (item.value / vmax) * barMax);
      const fill = item.highlight ? highlightColor : color;
      const display = item.display ?? item.value;
      return (
        `<text x="0" y="${y + rowH / 2 + 3}" font-size="9.5" fill="#16232f" font-family="Inter" font-weight="600">${item.label}</text>` +
        `<rect x="${labelW}" y="${(y + rowH * 0.22).toFixed(1)}" width="${barMax}" height="${(rowH * 0.56).toFixed(1)}" rx="2" fill="${track}"/>` +
        `<rect x="${labelW}" y="${(y + rowH * 0.22).toFixed(1)}" width="${bw.toFixed(1)}" height="${(rowH * 0.56).toFixed(1)}" rx="2" fill="${fill}"/>` +
        `<text x="${labelW + barMax + 8}" y="${y + rowH / 2 + 3}" font-size="9.5" fill="#16232f" font-family="Inter" font-weight="700">${display}</text>`
      );
    })
    .join("");

  return `<svg viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">${rows}</svg>`;
}

if (typeof module !== "undefined") module.exports = { lineTrend, barH };
