# Project Report — browser module

Client-side property launch deck generator: same layout, same CSS, same 5
pages as the Python deck-system — but runs entirely in the browser, and is
now a genuine **multi-project engine**, not a Valia-only tool.

## Architecture

```
PROJECT_STORE (or a real API/CRM/DLD feed later)
        ↓
   getProjects() / getProject(id)   — the only integration surface
        ↓
   validateProjectData(data)        — never throws, returns warnings
        ↓
   renderDeck(data)                 — pure function, no fetching, no DOM writes
        ↓
   #deck-report.innerHTML = ...
        ↓
   window.print()                   — real vector-text PDF, correct pagination
```

`renderDeck()` never assumes Valia, never assumes a project has 1-4BR
apartments, never assumes a 9-instalment payment plan, and never fabricates
a number it can't derive from the data it's given. Missing sections render
a labeled "Data unavailable" placeholder instead of breaking the page.

## Try it right now

Open `demo.html`. It ships with two example datasets in the dropdown:

- **Valia** — complete, matches the original reference deck exactly.
- **Farm Gardens** — deliberately thin. Only fields actually stated on
  the Pipeline tab's card are filled in; everything else is left absent
  on purpose, so you can see the "data unavailable" fallbacks and the
  validation warning banner trigger honestly, not staged.

Validated three ways before handing over (no browser in my sandbox to
click-test myself): syntax-checked every script block, ran the actual
code path through a real DOM engine (jsdom) including switching projects
via the dropdown and confirming the warning banner reacts correctly, and
rendered the produced HTML/CSS through WeasyPrint to confirm layout and
5- or 6-page pagination for both projects (Valia gets a 6th "Investment
Returns" page since it has real yield/appreciation data behind it; Farm
Gardens doesn't, so that page is simply omitted rather than faked — see
"Adding a returns page" below). Worth opening it yourself before
this goes near a client, though — that's the one thing I can't verify
from here.

## Files

```
demo.html              — open this directly, two example projects, working PDF export
icons.js               — icon set, ported 1:1 from template/icons.py
charts.js              — SVG chart generators, ported 1:1 from template/charts.py
calc.js                — unit metrics, best-value scoring, payment-plan and
                          project-data validation. Pure functions, no DOM.
render.js               — builds the HTML string from a data object (5 pages,
                          or 6 if page6 is present); exports renderDeck()
                          and validateProjectData()
deck-report.css         — all styling + print/PDF rules
example_data.json       — Valia, the complete reference dataset
data_farm_gardens.json  — Farm Gardens, the deliberately-incomplete dataset
test-render.js          — Node dev harness, not needed at runtime
```

## Adding a new project

Add an entry to `PROJECT_STORE` in `demo.html` (or wherever it lives in
your integration) with the same shape as the two examples. Every field is
optional except `project.name` and `agent.name` — anything else missing
just degrades gracefully with a placeholder, and `validateProjectData()`
will tell you what's missing before you export.

Payment plan instalments can be any number, any split — the renderer
loops over whatever array it's given and auto-detects the last one as the
"final" instalment for styling. `validatePaymentPlan()` checks the
percentages actually sum to 100 and returns a warning if not.

## Adding a returns page (page 6)

`page6` in a project's data is entirely optional. If present, a 6th
"Investment Returns" page renders — rental yield comparison, a 3-scenario
appreciation table, and a worked exit-math panel. If absent, the deck is
simply 5 pages; no placeholder, no "data unavailable" page. This is
different from every other section's fallback behavior on purpose —
a returns page needs real modeling behind it to be worth showing at all,
so it's opt-in rather than gracefully-degraded. See `example_data.json`'s
`page6` block for the full shape.

## Best-value scoring

`computeBestUnit()` in `calc.js` scores each unit type on price/sq ft
(55%), average size (25%), and entry price (20%) — plain constants at
the top of the file, not hidden magic numbers, adjust them per-project's
investment thesis if needed. It only ever compares unit types *within*
the same project, never claims a resale/appreciation promise, and is
visually and textually labeled "CALCULATED" in the deck so it's never
confused with the researched, hand-written market commentary elsewhere
on the page.

## Integrating into your own app

Once you have your host file:

1. Add `icons.js`, `charts.js`, `calc.js`, `render.js` into `<script>`
   tags (or one combined tag) — plain JS, no build step.
2. Add `deck-report.css` into a `<style>` tag.
3. Replace `PROJECT_STORE` with a real `getProjects()`/`getProject(id)`
   pair — swap the body for a `fetch()` call whenever there's a real
   pipeline/CRM/AI-research source to hit. Nothing else needs to change;
   the renderer only ever receives already-normalized data.
4. Wire a `<select>` to populate from `getProjects()` and call
   `renderReport(id)` on change (see `initProjectReport()` in demo.html
   for the exact pattern).
5. Wire "Download" to `window.print()`.

Image fields still need real file paths or data URLs — nothing here can
source images on its own (same limitation as the Python version).

## Design tokens

Colors, spacing, and type all live in `deck-report.css` under `:root` and
the `#deck-report .*` rules — same values as
`deck-system/template/style.css`. Keep both in sync if you change one,
unless you're intentionally diverging them.
