// Hand-drawn line icon set (24x24 viewBox), stroke-based — ported 1:1 from
// the Python deck-system's template/icons.py so both stay visually identical.
const ICONS = (() => {
  const wrap = (body, { color = "#ffffff", size = 20, sw = 1.6 } = {}) =>
    `<svg viewBox="0 0 24 24" width="${size}" height="${size}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;

  const bodies = {
    layers: '<path d="M12 3 2 8l10 5 10-5-10-5Z"/><path d="M2 13l10 5 10-5"/><path d="M2 18l10 5 10-5"/>',
    building: '<rect x="6" y="2.5" width="12" height="19" rx="0.6"/><path d="M9 6.2h1.4M13.6 6.2H15M9 9.6h1.4M13.6 9.6H15M9 13h1.4M13.6 13H15"/><rect x="10" y="16.3" width="4" height="5.2"/>',
    metro: '<path d="M6.5 3.5h11a2 2 0 0 1 2 2V15a3 3 0 0 1-3 3H7.5a3 3 0 0 1-3-3V5.5a2 2 0 0 1 2-2Z"/><path d="M4.5 15h15"/><rect x="7" y="6" width="4.2" height="4" rx="0.4"/><rect x="12.8" y="6" width="4.2" height="4" rx="0.4"/><path d="M8 21l-2 2M16 21l2 2"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="16" rx="2"/><path d="M3.5 10h17"/><path d="M8 3v4M16 3v4"/><path d="M8 14h2M14 14h2M8 17.5h2M14 17.5h2"/>',
    pin: '<path d="M12 21s7-6.1 7-11.3A7 7 0 0 0 5 9.7C5 14.9 12 21 12 21Z"/><circle cx="12" cy="9.6" r="2.3"/>',
    heart: '<path d="M12 20.5s-7.6-4.6-10-9.3C.5 7.8 2.3 4.5 5.8 4c2-.3 3.9.6 5 2.2C11.9 4.6 13.8 3.7 15.8 4c3.5.5 5.3 3.8 3.9 7.2-2.4 4.7-10 9.3-10 9.3Z"/>',
    grad_cap: '<path d="M2 9.5 12 5l10 4.5-10 4.5-10-4.5Z"/><path d="M6.5 11.7v4.4c0 1.4 2.5 2.9 5.5 2.9s5.5-1.5 5.5-2.9v-4.4"/><path d="M20 9.5v6"/>',
    hotel: '<path d="M3 21V8l6-4 6 4v13"/><path d="M15 21V11l6-2v12"/><path d="M9 21v-5h0"/><path d="M6.5 9h1M6.5 12h1M6.5 15h1M11.5 9h1M11.5 12h1"/>',
    walk: '<circle cx="13" cy="4.5" r="1.7"/><path d="M10 22l1.5-6-2-2 .8-5 3-1.2 2.8 2.5 3 1"/><path d="M9.3 14.2 6 16.5"/>',
    bike: '<circle cx="6" cy="17" r="3.2"/><circle cx="18" cy="17" r="3.2"/><path d="M6 17l4-9h4l3 9"/><path d="M10 8h3M11 8l3 5h4"/>',
    tree: '<path d="M12 3 7 10h3l-4 6h4v5h4v-5h4l-4-6h3L12 3Z"/>',
    mall: '<path d="M4 9 12 4l8 5"/><rect x="4" y="9" width="16" height="12" rx="1"/><path d="M9 21v-6h6v6"/><path d="M4 13h16"/>',
  };

  const api = {};
  for (const [name, body] of Object.entries(bodies)) {
    api[name] = (opts) => wrap(body, opts);
  }
  return api;
})();

if (typeof module !== "undefined") module.exports = ICONS;
