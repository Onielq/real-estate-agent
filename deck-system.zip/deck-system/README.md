# Property Launch Deck Generator

Turns a JSON file of project data into a 5-page investor-deck-style PDF,
matching the layout, colors, fonts, and structure of your reference deck
(cover / investment case / masterplan / comparables / location).

## Quick start

```bash
pip install jinja2 weasyprint --break-system-packages   # one-time setup

python3 generate.py data/example_valia.json output/my_deck.pdf
```

Open `output/my_deck.pdf`. That's the whole workflow.

## Making a deck for a new project

1. Copy `data/_template_blank.json` to something like `data/my_project.json`.
2. Delete the `_comment` key.
3. Fill in every field. Text fields are self-explanatory; a few notes below.
4. Run:
   ```bash
   python3 generate.py data/my_project.json output/my_project.pdf
   ```
5. The script prints two lists before it writes the PDF:
   - **REQUIRED inputs missing** — agent photo and cover hero image. Without
     these the deck will still generate, but with an obvious placeholder box
     where the image should be.
   - **Recommended images missing** — floor plan, masterplan map, location
     map, amenity photo. Same deal: placeholder box, deck still works.

## Images — read this

This system cannot find or download real estate renders, floor plans, maps,
or headshots on its own. There's no web-browsing step built in. Every image
field in the JSON is a **file path you provide**:

```json
"hero_image": "/path/to/your/tower-render.jpg"
```

Leave it `null` (or an empty string) and a labeled placeholder box renders
in its place instead of breaking the layout. That's intentional — it means
you can generate a complete draft deck before you have final renders, see
exactly which images are still needed, and drop them in later.

If you want Claude to help **research** market figures (price/sq ft trends,
comparable pricing, absorption rates, etc.) to fill in the text fields,
do that in a chat with web search turned on — paste the findings into the
JSON. This generator itself doesn't fetch anything from the internet.

## File map

```
generate.py          — run this. Loads JSON, renders template, writes PDF.
template/deck.html.j2 — the 5-page layout (Jinja2 + HTML/CSS)
template/style.css    — colors, type, spacing tokens
template/icons.py     — hand-drawn line icon set (layers, building, metro, etc.)
template/charts.py    — SVG line-trend and horizontal-bar chart generators
fonts/                — Playfair Display + Inter, static weights
data/example_valia.json     — full working example (the deck you uploaded)
data/_template_blank.json   — copy this to start a new project
```

## Customizing the design

- **Colors / fonts**: edit the CSS variables at the top of `template/style.css`
  (`--navy-950`, `--gold`, `--cream`, etc.)
- **Your branding**: `agent`, `watermark`, and `footer_brand` in the JSON —
  no code changes needed.
- **Adding a 6th page or changing a layout**: edit `template/deck.html.j2`
  directly. Each page is a `<div class="page pN">...</div>` block; copy an
  existing one as a starting point.

## Known WeasyPrint gotcha (already fixed here, worth knowing)

If you add a new flex-based two-column section and one column mysteriously
stops rendering: check whether any element in that column has a **fixed
height** that pushes total page content past the 7.5in page boundary.
WeasyPrint silently drops flex items that overflow a page instead of
clipping them — no error, no warning. Fix is to remove the fixed height and
let it size naturally, or shrink surrounding spacing so everything fits.
This bit us on page 2's side panel during development; the fix is already
in the template, just flagging it in case you extend the layout later.

## Regenerating the reference comparison

If you tweak the template and want to sanity-check it against the original
deck's page proportions, the original was rendered at 150dpi from the
uploaded PDF — `pdftoppm -png -r 150 original.pdf reference/page` — then
compared side-by-side against `pdftoppm -png -r 150 output/my_deck.pdf render/out`.
