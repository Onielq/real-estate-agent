#!/usr/bin/env python3
"""
Property launch deck generator.
Usage: python3 generate.py data/example_valia.json output/valia_deck.pdf
"""
import sys, json, os
from pathlib import Path
from jinja2 import Environment, FileSystemLoader
from weasyprint import HTML

ROOT = Path(__file__).parent
TEMPLATE_DIR = ROOT / "template"

sys.path.insert(0, str(TEMPLATE_DIR))
import icons as ICONS
import charts as CHARTS

ICON_FUNCS = {
    "layers": ICONS.layers, "building": ICONS.building, "metro": ICONS.metro,
    "calendar": ICONS.calendar, "pin": ICONS.pin, "heart": ICONS.heart,
    "grad_cap": ICONS.grad_cap, "hotel": ICONS.hotel, "walk": ICONS.walk,
    "bike": ICONS.bike, "tree": ICONS.tree, "mall": ICONS.mall,
}

REQUIRED_IMAGE_FIELDS = [
    ("agent.photo", "Agent headshot"),
    ("project.hero_image", "Cover hero image (tower exterior render/photo)"),
]

RECOMMENDED_IMAGE_FIELDS = [
    ("page2.differentiator.image", "Floor plan / layout diagram (page 2)"),
    ("page3.hero_image", "Masterplan aerial / hero band image (page 3)"),
    ("page3.map_image", "Masterplan / district map (page 3)"),
    ("page5.mall_image", "Landmark / amenity photo (page 5)"),
    ("page5.location_map_image", "Location map (page 5)"),
]

def icon(name, color="#ffffff", size=20, sw=1.6):
    fn = ICON_FUNCS.get(name)
    if not fn:
        return ""
    return fn(color=color, size=size, sw=sw)

def check_missing(data):
    """Report fields the person still needs to supply — mainly images we
    have no way of sourcing automatically (renders, floor plans, maps, photos)."""
    def get(path):
        cur = data
        for p in path.split("."):
            cur = cur.get(p, {}) if isinstance(cur, dict) else {}
        return cur if cur != {} else None

    required, recommended = [], []
    for path, desc in REQUIRED_IMAGE_FIELDS:
        if not get(path):
            required.append(f"{path}  ->  {desc}")
    for path, desc in RECOMMENDED_IMAGE_FIELDS:
        if not get(path):
            recommended.append(f"{path}  ->  {desc}")
    return required, recommended

def main():
    if len(sys.argv) < 3:
        print("Usage: python3 generate.py <data.json> <output.pdf>")
        sys.exit(1)

    data_path = Path(sys.argv[1])
    out_path = Path(sys.argv[2])
    data = json.loads(data_path.read_text())

    required, recommended = check_missing(data)
    if required:
        print("✗  REQUIRED inputs missing (deck will look broken without these):")
        for m in required:
            print("   -", m)
        print()
    if recommended:
        print("⚠  Recommended images missing (a labeled placeholder will render instead):")
        for m in recommended:
            print("   -", m)
        print()

    base_css = (TEMPLATE_DIR / "style.css").read_text()

    env = Environment(loader=FileSystemLoader(str(TEMPLATE_DIR)))
    env.globals["icon"] = icon
    env.globals["line_trend"] = CHARTS.line_trend
    env.globals["bar_h"] = CHARTS.bar_h
    template = env.get_template("deck.html.j2")

    html_str = template.render(base_css=base_css, icon=icon, **data)

    html_out = out_path.with_suffix(".html")
    html_out.write_text(html_str)

    HTML(string=html_str, base_url=str(TEMPLATE_DIR) + "/").write_pdf(str(out_path))
    print(f"✓ PDF written to {out_path}")

if __name__ == "__main__":
    main()
