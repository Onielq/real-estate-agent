"""Tiny dependency-free SVG chart generators sized in points (pt) to sit
cleanly inside the PDF layout."""

def line_trend(points, width=300, height=90, color="#c9a15a", axis_color="#8993a0", value_fmt="{:,}"):
    """points: list of {"label": str, "value": number}"""
    n = len(points)
    if n < 2:
        return ""
    pad_l, pad_r, pad_t, pad_b = 26, 26, 22, 18
    plot_w = width - pad_l - pad_r
    plot_h = height - pad_t - pad_b
    vals = [p["value"] for p in points]
    vmin, vmax = min(vals), max(vals)
    vspan = (vmax - vmin) or 1
    xs = [pad_l + (i / (n - 1)) * plot_w for i in range(n)]
    ys = [pad_t + plot_h - ((v - vmin) / vspan) * plot_h for v in vals]

    path = " ".join(f"{'M' if i==0 else 'L'} {xs[i]:.1f} {ys[i]:.1f}" for i in range(n))
    dots = "".join(f'<circle cx="{xs[i]:.1f}" cy="{ys[i]:.1f}" r="2.6" fill="{color}"/>' for i in range(n))
    anchors = ["start"] + ["middle"] * (n - 2) + ["end"] if n > 2 else ["start", "end"]
    labels_v = "".join(
        f'<text x="{xs[i]:.1f}" y="{ys[i]-8:.1f}" font-size="9" font-weight="700" fill="#16232f" text-anchor="{anchors[i]}" font-family="Inter">{value_fmt.format(vals[i])}</text>'
        for i in range(n)
    )
    labels_x = "".join(
        f'<text x="{xs[i]:.1f}" y="{height-4}" font-size="7.6" fill="{axis_color}" text-anchor="{anchors[i]}" font-family="Inter">{points[i]["label"]}</text>'
        for i in range(n)
    )
    return (
        f'<svg viewBox="0 0 {width} {height}" width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">'
        f'<path d="{path}" fill="none" stroke="{color}" stroke-width="2"/>'
        f'{dots}{labels_v}{labels_x}</svg>'
    )


def bar_h(items, width=380, row_h=26, color="#13213b", track="#ede9de", highlight_color="#c9a15a"):
    """Horizontal bar chart. items: list of {"label", "value", "display", "highlight": bool}"""
    n = len(items)
    height = n * row_h
    vmax = max(i["value"] for i in items) or 1
    label_w = 78
    val_w = 46
    bar_max = width - label_w - val_w - 8
    rows = []
    for i, item in enumerate(items):
        y = i * row_h
        bw = max(4, (item["value"] / vmax) * bar_max)
        fill = highlight_color if item.get("highlight") else color
        rows.append(
            f'<text x="0" y="{y+row_h/2+3}" font-size="9.5" fill="#16232f" font-family="Inter" font-weight="600">{item["label"]}</text>'
            f'<rect x="{label_w}" y="{y+row_h*0.22:.1f}" width="{bar_max}" height="{row_h*0.56:.1f}" rx="2" fill="{track}"/>'
            f'<rect x="{label_w}" y="{y+row_h*0.22:.1f}" width="{bw:.1f}" height="{row_h*0.56:.1f}" rx="2" fill="{fill}"/>'
            f'<text x="{label_w+bar_max+8}" y="{y+row_h/2+3}" font-size="9.5" fill="#16232f" font-family="Inter" font-weight="700">{item.get("display", item["value"])}</text>'
        )
    return (
        f'<svg viewBox="0 0 {width} {height}" width="{width}" height="{height}" xmlns="http://www.w3.org/2000/svg">'
        + "".join(rows) + "</svg>"
    )
